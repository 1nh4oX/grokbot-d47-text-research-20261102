# D75—D83 免费历史来源多轮测试结果

2026-10-19。本批连续9轮，共203次程序HTTP/RPC小请求（不含网页发现检索），完成独立离线复核。D47-v1队列、标签、截止与任务不变；无Dune、模型训练、全量下载、服务器作业或独立测试。

## 当前结论

**首次打通可验证正负控制的Telegram合约/池检索，并找到两条原队列币的首周第三方原始喊单。** 路径为“完整合约检索→喊单索引引用→准确原消息→冻结交易池→历史token0/token1”。此前只匹配token CA会漏掉只贴交易池链接的帖子。

但数据还不足以做文本增量模型：聚合器记录有明显编辑标记，含不明时点更新的ROI/CPW；两条原始叙述没有可见编辑标记，也没有独立截止前正文快照。未检出不能填零讨论。来源关联进展不等于预测增益，更不是论文贡献。

## 各轮实际结果

| 编号 | 实际请求 | 检查 | 结论 |
|---|---:|---|---|
| D75 | 30 | 7个新HF集、60行预览、8次服务端搜索 | Solana链上/代理生成分析、旧金融喊单、旧新闻或地址标签；未取得D47社区语料。8个search均网络失败，不是零结果 |
| D76 | 15 | 已知Reddit ID、两种窄关键词控制、6个新社区日窗、6评论小样本 | ID正控制成功，但关键词正控制422超时；76帖5地址提及无原队列命中；评论0返回含1超时，不当零讨论 |
| D77 | 9 | Searchcaster代码、路由和实际接口 | 仓库已归档，代码路由转deprecated；服务HTTP410，停止，不继续发目标查询 |
| D78 | 12 | 历史新闻API、Mendeley、两DEX论坛 | 新闻API401需key后停止；Sushi404；Balancer40帖子记录中12在请求月份，无命中；Mendeley只读100KB |
| D79 | 20 | 4个第三方TG频道与有界历史定位 | 353去重消息，30条在2025-09至11；无原币地址命中。部分频道日期断档/仅门户，EVM格式不等于Ethereum |
| D80 | 16 | CallAnalyser ETH索引，正负控制、4已绑定+6盲样本 | 控制通过；命中Chis一条首周记录，打通新检索路径 |
| D81 | 46 | 既有49币并集，复用10次旧查询、39新查询，追原文引用 | 6币首周聚合记录；准确读到2个引用原帖，另3个引用不可复原。聚合数据不训练 |
| D82 | 5 | 冻结池映射、两池历史token0/token1 | 两条原始喊单通过池链接关联原token；两池历史均为原token/WETH |
| D83 | 50 | 两个原始频道正负控制，原D72固定24币池检索 | 两控制通过；48个目标查询、2次控制同URL复用，实际50请求；只重复检出上述2币，没有新增独立案例 |

所有来源均有回执和哈希。执行中两个公开读取的自动权限审查超时，按系统提示各重试一次后成功；不是研究结果。Mendeley路由补充脚本首次因未配置主机白名单在发请求前停止，修复后执行，保留attempt1计划；没有因此增加请求预算。

## 新检索路径及覆盖

[CallAnalyser公开页](https://t.me/s/CallAnalyser)的已知地址搜索正控制返回原记录，唯一无意义字符串负控制不返回消息，未回落到默认主页。其地址搜索不同于之前反复失败的通用网页/Reddit关键词搜索。

D81使用既有D65、D72、D70样本并集49币，没有按恢复结果换币。6个精确资产首周命中：AGAI、BFX、CHISAI、CCF、MAXI、ETHDOGS。全部是Total Call聚合消息且有可见edited标记，不等于6份可直接用于预测的原始文本。其Score、ROI、CPW、涨幅与调用者当下成绩不进入预测特征。

| 原样本组 | 样本数 | HTTP200查询 | 首周资产命中币 |
|---|---:|---:|---:|
| D65原盲抽 | 18 | 18 | 0 |
| D72固定分层 | 24 | 24 | 4 |
| D70高首周量目的性 | 9 | 9 | 3 |

组有重合，不能相加，也不能用6/49估总体覆盖。D72四个命中中3币属于首周交易数≥1000层、1币属于100–999层；每层样本很小，只提示注意高活跃选择偏差，不能给出总体规律。D83两个调用者正是因为已找到原文才选定，2/24也不是无偏频道覆盖估计。

## 两条原始叙述如何对应token

| 原帖 | 创建UTC | 原文链接中的池 | 历史映射 |
|---|---|---|---|
| [ClasierCalls/2755](https://t.me/ClasierCalls/2755) | 2025-09-19 13:46:44 | 0xc0e63cb34db807c3fc9b99d2995601f16bd5f98c | BFX 0xcd3155156db5facc6b160cdfc0846a8dad786e56 + WETH，块23394129 |
| [DoxxedChannel/15658](https://t.me/DoxxedChannel/15658) | 2025-11-12 18:37:30 | 0x7cc72fe47c3ea72eed8d3191681fd68f60dec4bb | CCF 0xf0ff1251c88ffc52fc061eb41690b2ab68986753 + WETH，块23784843 |

两条都落在原币launch_date UTC起7日内，明确ethereum/ether池URL；冻结注册表与独立历史RPC一致。没有使用今天DEX配对补过去身份。BFX文本是平台/测试版推广，CCF是教育、捐赠和权威关联的叙述；这些是发帖者的宣称，不能认定项目履约或真实慈善关联。

原始两条均无当前可见edited标记；这比明确编辑的聚合ROI记录少一项风险，但仍不是历史不可变证明。准确原消息ID很重要：Zorrogems/8169页面实际返回912—921，故不能把HTTP200当读到所引用原文；Akazagem两个引用均未读到正文。禁止将这些回落页算作原帖成功。

## 其他来源排除依据

HF的[MELT](https://huggingface.co/datasets/Zinteck/MELT)是Solana链上行为集；[CryptoLM ETH/USDT](https://huggingface.co/datasets/WinkingFace/CryptoLM-Ethereum-ETH-USDT)是价格/技术指标；[Pumpfun Corpus](https://huggingface.co/datasets/Slinky21/Pumpfun_Memecoin_Corpus)实际预览是mint/迁移时间，不能因Text标签当社区文本。[Pump Studio sentiment](https://huggingface.co/datasets/Pumpdotstudio/pump-fun-sentiment-100k)是代理根据链上数据生成的分析，不是独立人类社区信息。Telegram金融信号样例为2022年外汇；CoinDesk卡片明确截止2025-01-01，不因名称“2020–2025”误当覆盖2025-09；地址标签集没有本任务逐帖历史文本。上传日期不能替代正文日期。

[CryptoVision](https://data.mendeley.com/datasets/wvjjxr8bxx/2)原CSV约64.36MB，网页最初两条猜测API均404；静态读取网站自身脚本后找到正确匿名文件清单路由。服务器实际支持206，只读bytes0–99999，20行样例在2017年。作者称2017—2025，不代表已验证覆盖D47首周；没有下载全量，也不据开头样本判定整个文件只到2017。该集主要市场新闻，不冒充原币社区；预制情绪标签亦不能直接当本任务标签。

## 数据如何利用及本批停止条件

当前可做的是完善“token CA与历史池双路径”的文本关联器，把两条原文作为可审计案例。正式实验继续用既定同成员对照：仅链上、加历史可证明的文本可用状态、再加内容表示。第三方喊单/广告、项目自述、用户讨论、机器人统计分开，不能混成一个情绪总分。

当前聚合器只作发现渠道，不把整段统计文本喂模型。未来若来源门通过，可检验原始叙述中产品/开发、交易接入、营销、捐赠/权威引用等语言信息是否超过链上基线；先清除地址/链接/币名及事后指标，做缺失和内容置换对照。原始有无编辑记录、源内检索覆盖/删除偏差仍需说明。来源不足时不训练，也不因免费抓不到就断言文本无效。

最后两频道小样本检索没有新增案例，本批按协议停止。下一步将“当前未标编辑原文可代表当时正文”写成明确的回溯假设，并据此设计来源/版本敏感性；再准备固定训练范围、来源分层的扩采小批次，不能直接把49币并集或今天检索状态当训练数据。任何大规模下载仍由用户手动启动。独立测试仍未用。

## 文件索引

九个输出目录分别为outputs/D75_dataset_search、D76_reddit_narrow、D77_farcaster_discovery、D78_alternative_history、D79_telegram_history、D80_eth_call_search、D81_call_coverage、D82_pool_link_binding、D83_direct_caller_search，均有COMPLETE_VERIFIED；它们证明记录完整性，不是训练准入。

关键：D81以complete_summary.json为准，原summary.json保留；D78同样使用complete_summary.json，40论坛记录只有12条在目标月份，见reviewed_forum_scope.json。D82的original_call_text_candidates.json仅两条原文，historical_pool_bindings.json包含链上证据。D83是相同原文的覆盖复核，不重复累计数据量。复核reports/D75_D82_source_verification.json与reports/D75_D83_source_verification.json；31项＋8项通过，203请求，strict_training_ready=false。
