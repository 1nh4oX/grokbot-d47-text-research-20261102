# D109—D113：独立存档受阻，新增一份核验网页快照
2026-10-25。本轮完成10次公开源HTTP和2次只读Telegram数据RPC。新增Kanro一份首周网页快照，正文SHA-1与档案索引一致，响应捕获时间与首周截止一致；原D94的23帖子保留，新增网页独立分型，共24文本证据单元/9币，覆盖币数未增加。未训练、没有模型增益或独立测试结论。

## 新证据：Kanro首周网页
原token 0xc149e7cc954e96c7147f0babcd4a349dce47dd8f，首周2025-10-25T00:00Z至11-01T00:00Z；抓取于2025-10-27T03:21:07Z。原URL https://www.kanrofund.xyz/ ，准确重放请求HTTP200、无跳转，Memento-Datetime同秒；23648字节原始HTML的SHA-1 Base32为CO2CEHAC4A743ZI5S2WWO3T54OJ5L6NB，与CDX digest完全一致。可见正文含完整原CA，etherscan/token和Ethereum资产链接均对应原币。
这是“当时可见网页内容”的强一致性证据，不是页面首次发布时间；首次发布时间未知。捕获时间不能当发帖/项目成立时间，也不能从一个网页推日均发帖数。代码保留absolute_immutability_proven=false，不把单一档案平台的一致性说成绝对不可变保证。
页面包含公益与名人/基金会关联宣传，并嵌入2023年的外部推文；这些关系、捐赠与安全/代币经济自述均未核实，不能写作事实，更不能把2023引文当成2025 token事件。既有Kanro的5条X文本已有类似公益/权威语言，因此这次主要增强版本与身份证据；尚未证明新增语义信息或预测信号。重复段落和ticker是网页模板，不算多条社区消息。
历史页面引用KanroFundETH，说明该文字入口在快照中出现；尚未与稳定Telegram数字ID闭合，更不认证官方所有权。原D97对捐赠钱包/同名/跨平台映射的限制继续适用。

## 如何选到该快照
D106原24中有10币/12个项目网站或docs候选；D107—108已检查固定4币。本轮不替换这4币，把它们的未完成/失败保留；D112只补原清单全部剩6币，按原父顺序EthOS、Magenta、Pumpkin、Kanro、Bro、MAXI各1准确首页首周CDX查询。
六次均HTTP200：EthOS、Magenta、Pumpkin、Bro查询空；Kanro与MAXI各有1首周索引。按采集前顺序，只读取首个合格来源Kanro，不根据重放成功/结局挑源。MAXI首周索引2025-11-16T06:26:01Z原URL https://www.maxidogememe.fun/ 尚未读取正文；不能提前计候选或其正文版本已过。
网页来源仍由已有源码链接筛选，有选择偏差；仅准确根页查询，不覆盖全站。当前无新增网页快照正负控制，不用4个空索引估总体无社区概率，也不把今日可搜索性写成首周缺失特征。Magenta旧身份冲突不因本次空索引解除。

## 独立来源和API的受阻部分
D109按官方元数据核对Common Crawl时间：9月集合抓取9/5—18，11月集合11/6—19。因此BFX的9/19—26首周无重叠，不发目标查询；AIMINE首周仅1日重叠、Marshall6日、AgenFi7日。集合有重叠也不保证某URL被抓。[9月官方说明](https://commoncrawl.org/blog/september-2025-crawl-archive-now-available)，[11月官方说明](https://commoncrawl.org/blog/november-2025-crawl-archive-now-available)。
已知get-started索引正控制200并返回官方预期记录，唯一负控制504；按停止规则，四币目标索引均未执行，不记作目标0命中。D111仅单独核验正控制记录的Range接口，12695字节范围请求返回503，未取得正文、不下载完整WARC。官方支持按filename/offset/length读取单记录，但本地这次未读成功，不声称已跑通正文采集。[官方CDXJ与Range示例](https://www.commoncrawl.org/cdxj-index)。
D110已知TERPS池原帖控制正常，AIMINE_Official解析返回UsernameInvalidError，未得到稳定ID/对象类型，没有读该入口任何历史或私聊；不能据此说是私人账号、已注销或过去无频道。当前网站与源码引用仍只作候选。
本轮源请求总计D1092+D1111+D1127=10HTTP，另D1102RPC，不为耗尽预算重试故障服务。所有原采集前计划与失败留存；D112是不同服务上的原有余6来源，不绕过Common Crawl控制去查其目标。

## 后续及使用限制
下一步只需先核验已经找到的MAXI准确快照：最多1次公开重放，核对实际响应时间/跳转/完整原CA/链与索引digest；失败保留，不猜新日期、不用当前页代替。MAXI结局此前已看，后续仅属既有固定样本来源核验，不称新盲测、不能借已知正例宣称覆盖提升有代表性。
文本建模仍等待更多覆盖及可比来源。未来网页与社媒分型，标注外部引用/模板重复；沿用同一D47队列、标签、截止和公平对照，词表/降维仅训练折拟合，不能因这一快照改六类词表追求开发集提升。大规模下载仍用户手动启动，服务器使用前先核对同步；本轮轻量本地完成。

## 留存/核验
outputs/D109_commoncrawl/all4_source_status.json保留四币未执行/结构缺口；D110_aimine_identity/resolution_audit.json保留类型未知；D111_cc_record_control保存503与空body；D112_remaining_websites保存6索引、1原文及投影。
outputs/D113_archived_website_admission/new_web_snapshot.json为新增网页证据；combined_candidate_inventory.jsonl保留原23帖子+1网页，不覆盖D94。manual_review.json明确语义增量未证实与已有叙述重合。独立存档一致性字段已补，但所有formal_training_ready=false。
reports/D109_D113_verification.json12项完整性/预算/分母核验、D113_verification.json11项捕获/身份/原文校验均通过；不证明网页宣称真实或模型增益。D109另4合成WARC检查过，真实WARC读取仍503。凭据/session未输出或纳入索引。
